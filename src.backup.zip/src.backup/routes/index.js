
import Home from '../screens/Home';
import Detail from '../screens/Detail';

const MainStackNav = {
  Home: {
    screen: Home
  },
  Detail: {
    screen: Detail
  }
};

export default MainStackNav;
