import { createStackNavigator } from 'react-navigation'

import MainStackNav from './routes'

const AppNavigator = createStackNavigator(MainStackNav)

export default AppNavigator
