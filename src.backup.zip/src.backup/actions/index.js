import * as nav from './nav'

export default {
  ...nav
};
