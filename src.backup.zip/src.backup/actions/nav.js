import { createAction } from 'redux-actions'

export const resetNavHome = createAction('RESET_NAV_HOME')
